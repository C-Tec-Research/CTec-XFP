﻿using CTecControls.UI;
using CTecUtil;
using CTecUtil.UI.Util;
using Microsoft.Toolkit.Uwp.Notifications;
using System;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Xfp.Config;
using Xfp.ViewModels;
using Notification.Wpf;
using System.Windows.Media;

namespace Xfp.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            EventLog.WriteInfo("Starting app");

            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement), new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

            InitializeComponent();

            DataContext = _context = new MainWindowViewModel(this);

            //restoreWindowState();
            
            _messageTimer = new() { Interval = 1000 };
            _messageTimer.Elapsed += (s, a) => _notificationManager.Show("Pink string from another thread!");
        }


        private bool _allowSaveWindowState = false;

        private MainWindowViewModel _context;


        private void window_Loaded(object sender, RoutedEventArgs e) { }



        #region Window controls & resizing
        private void btnMinimise_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups();*/ WindowState = WindowState.Minimized; }
        private void btnMaximise_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups();*/ WindowState = WindowState.Maximized; XfpApplicationConfig.Settings.MainWindow.IsMaximised = true; /*updateWindowParams(true);*/ }
        private void btnRestore_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups(); XfpApplicationConfig.Instance.RestoreMainWindowState(this);*/ WindowState = WindowState.Normal; XfpApplicationConfig.Settings.MainWindow.IsMaximised = false; /*updateWindowParams(true);*/ }
        private void window_StateChanged(object sender, EventArgs e) { /*_context.ClosePopups();*/ _context.ChangeWindowState(WindowState); }
        private void btnExit_Click(object sender, RoutedEventArgs e) => exitApp();

        private void window_SizeChanged(object sender, SizeChangedEventArgs e) { updateWindowParams(); }
        private void window_LocationChanged(object sender, EventArgs e) {updateWindowParams(); }

        private void mouseLeftButtonDown_DragMove(object sender, MouseButtonEventArgs e) { try { DragMove(); updateWindowParams(); } catch { } }

        /// <summary>App lost focus</summary>
        private void app_Deactivated(object sender, EventArgs e) { }

        /// <summary>Alt-F4</summary>
        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e) => exitApp(e);

        private void exitApp(System.ComponentModel.CancelEventArgs e = null)
        {
            XfpApplicationConfig.Settings.UpdateMainWindowParams(this, true);
            EventLog.WriteInfo("Exiting app");
            _context?.ExitApp();
        }


        private void updateWindowParams() { if (_allowSaveWindowState) XfpApplicationConfig.Settings.UpdateMainWindowParams(this, _context.LayoutTransform.ScaleX); }

        private void restoreWindowState()
        {
            if (App.AnotherInstanceIsRunning)
                XfpApplicationConfig.Settings.OffsetMainWindowPosition();

            if (XfpApplicationConfig.Settings.MainWindow.Location is null)
                this.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            else
                _context.ChangeWindowState(this.WindowState = WindowUtil.SetWindowDimensions(this, XfpApplicationConfig.Settings.MainWindow));

            this.BringIntoView();
        }


        #region prevent maximised window from being clipped
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            WindowUtil.PreventClipWhenMaximised(this);
        }
        #endregion


        #endregion



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //AppNotification.Show("Test notification", "line 2", "Line 3", "Fourth line", "etc.");
            ShowNotification("Test notification", "line 2", "Line 3", "Fourth line", "etc.");
        }


        public static void ShowNotification(params string[] text)
        {
            var notification = new ToastContentBuilder();

            notification.AddInlineImage(new Uri("pack://application:,,,/Xfp;component/Resources/xfp.ico"));
            notification.AddInlineImage(new Uri("pack://application:,,,/Xfp;component/UI/Images/xfp.ico"));

            for (int i = 0; i < text.Length && i < 3; i++)
                notification.AddText(text[i]);

            notification.Show(toast => { toast.ExpirationTime = DateTime.Now.AddMinutes(15); });
        }


        #region notification.wpf
        private readonly NotificationManager _notificationManager = new NotificationManager();
        private readonly Random _random = new Random();


        private System.Timers.Timer _messageTimer;

        private void Timer_Click(object sender, RoutedEventArgs e)
        {
            if(!_messageTimer.Enabled) _messageTimer.Start();
            else _messageTimer.Stop();
        }

        private async void AllColours_Click(object sender, RoutedEventArgs e)
        {
            for (var i = 0; i <= 5; i++)
            {
                var content = new NotificationContent
                {
                    Title = "Sample notification",
                    Message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
                    Type = (NotificationType)i
                };
                await Task.Delay(TimeSpan.FromSeconds(1));
                _notificationManager.Show(content);

            }

        }

        private void InWindow_Click(object sender, RoutedEventArgs e)
        {
            var content = new NotificationContent {Title = "Notification in window", Message = "Click me!"};
            var clickContent = new NotificationContent
            {
                Title = "Clicked!",
                Message = "Window notification was clicked!",
                Type = NotificationType.Success
            };
            _notificationManager.Show(content, "WindowArea", onClick: () => _notificationManager.Show(clickContent));
        }

        private async void Info_Click(object sender, RoutedEventArgs e)
        {
            var clickContent = new NotificationContent
            {
                Title = "Clicked!",
                Message = "Window notification was clicked!",
                Type = NotificationType.Success
            };

            var title = "Sample notification";
            var Message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";
            var type = NotificationType.Notification;

            _notificationManager.Show(title, Message, type, "WindowArea", onClick: () => _notificationManager.Show(clickContent));
            _notificationManager.Show(title, Message, type, "", onClick: () => _notificationManager.Show(clickContent));

        }

        private async void Progress_Click(object sender, RoutedEventArgs e)
        {
            var title = "Progress Bar";

            _notificationManager.ShowProgressBar(out var progress, out var Cancel, title, true, true);
            using (progress)
                try
                {
                    //await CalcAsync(progress, Cancel).ConfigureAwait(false);

                    await Task.Run(async () =>
                    {
                        for (var i = 0; i <= 100; i++)
                        {
                            Cancel.ThrowIfCancellationRequested();
                            progress.Report((i, $"Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n"
                                                + $"Lorem ipsum dolor sit amet, consectetur adipiscing elit.", null, null));
                            await Task.Delay(TimeSpan.FromSeconds(0.03), Cancel);
                        }
                    }, Cancel).ConfigureAwait(false);

                    for (var i = 0; i <= 100; i++)
                    {
                        Cancel.ThrowIfCancellationRequested();
                        progress.Report((i,$"Progress {i}", "Whith progress", true));
                        await Task.Delay(TimeSpan.FromSeconds(0.02), Cancel).ConfigureAwait(false);
                    }

                    for (var i = 0; i <= 100; i++)
                    {
                        Cancel.ThrowIfCancellationRequested();
                        progress.Report((null,$"{i}", "Whithout progress", null));
                        await Task.Delay(TimeSpan.FromSeconds(0.05), Cancel).ConfigureAwait(false);
                    }

                    for (var i = 0; i <= 100; i++)
                    {
                        Cancel.ThrowIfCancellationRequested();
                        progress.Report((i, null, "Agane whith progress", null));
                        await Task.Delay(TimeSpan.FromSeconds(0.01), Cancel).ConfigureAwait(false);
                    }


                }
                catch (OperationCanceledException)
                {
                    _notificationManager.Show("Операция отменена", "", TimeSpan.FromSeconds(3));
                }
        }

        public Task CalcAsync(IProgress<(int, string,string,bool?)> progress, CancellationToken cancel) =>
            Task.Run(async () =>
            {
                for (var i = 0; i <= 100; i++)
                {
                    cancel.ThrowIfCancellationRequested();
                    progress.Report((i, $"Процесс {i}",null, null));
                    await Task.Delay(TimeSpan.FromSeconds(0.01), cancel);
                }
            }, cancel);

        private void MessageWithButton_Click(object sender, RoutedEventArgs e)
        {
            _notificationManager.Show("2 button","This is 2 button on form","",TimeSpan.MaxValue,
                (o, args) => _notificationManager.Show("Left button click","",TimeSpan.FromSeconds(3)),"Left Button",
                (o, args) => _notificationManager.Show("Right button click", "", TimeSpan.FromSeconds(3)), "Right Button"); 
            
            _notificationManager.Show("2 button", "This is 2 button on form with standard name", "",TimeSpan.MaxValue,
                (o, args) => _notificationManager.Show("Left button click","",TimeSpan.FromSeconds(3)),null,
                (o, args) => _notificationManager.Show("Right button click", "", TimeSpan.FromSeconds(3)), null);

            _notificationManager.Show("1 right button","This is 1 button on form with standard name","",TimeSpan.MaxValue,
                (o, args) => _notificationManager.Show("Right button click", "", TimeSpan.FromSeconds(3)));

        }

        private void ShowContent_Click(object sender, RoutedEventArgs e)
        {
            var grid = new Grid();
            var text_block = new TextBlock { Text = "Some Text", Margin = new Thickness(0, 10, 0, 0), HorizontalAlignment = HorizontalAlignment.Center };


            var panelBTN = new StackPanel { Height = 100, Margin = new Thickness(0, 40, 0, 0) };
            var btn1 = new Button { Width = 200, Height = 40, Content = "Cancel" };
            var text = new TextBlock {Foreground = Brushes.White, Text = "Hello, world", Margin = new Thickness(0, 10, 0, 0), HorizontalAlignment = HorizontalAlignment.Center};
            panelBTN.VerticalAlignment = VerticalAlignment.Bottom;
            panelBTN.Children.Add(btn1);

            var row1 = new RowDefinition();
            var row2 = new RowDefinition();
            var row3 = new RowDefinition();

            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());


            grid.HorizontalAlignment = HorizontalAlignment.Center;
            grid.Children.Add(text_block);
            grid.Children.Add(text);
            grid.Children.Add(panelBTN);

            Grid.SetRow(panelBTN, 1);
            Grid.SetRow(text_block, 0);
            Grid.SetRow(text, 2);

            object content = grid;

            _notificationManager.Show(content,null,TimeSpan.MaxValue);

        }
        #endregion


    }
}
