﻿using System.Windows;

namespace Notification.Wpf
{
    /// <summary>
    /// Interaction logic for ToastWindow.xaml
    /// </summary>
    public partial class NotificationsOverlayWindow : Window
    {
        public NotificationsOverlayWindow()
        {
            InitializeComponent();
        }
        
    }
}
