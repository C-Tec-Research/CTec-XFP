﻿using System.Windows;

namespace Notifications.Wpf.Core.Caliburn.Micro.Sample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}