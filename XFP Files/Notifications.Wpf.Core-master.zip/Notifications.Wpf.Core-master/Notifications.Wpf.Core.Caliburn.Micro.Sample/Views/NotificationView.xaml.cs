﻿using System.Windows.Controls;

namespace Notifications.Wpf.Core.Caliburn.Micro.Sample.Views
{
    /// <summary>
    /// Interaction logic for NotificationView.xaml
    /// </summary>
    public partial class NotificationView : UserControl
    {
        public NotificationView()
        {
            InitializeComponent();
        }
    }
}