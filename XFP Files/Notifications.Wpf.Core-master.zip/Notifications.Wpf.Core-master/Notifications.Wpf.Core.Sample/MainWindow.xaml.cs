﻿using System;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using CTecControls.UI.Notifications;

namespace Xfp.Sample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void ShowNotification_Click(object sender, RoutedEventArgs e)
        {
            TestNotifications.Show("Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "Info");
        }

        private void ShowSuccess_Click(object sender, RoutedEventArgs e)
        {
            TestNotifications.ShowSuccess("Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "Success");
        }

        private void ShowWarning_Click(object sender, RoutedEventArgs e)
        {
            TestNotifications.ShowWarning("Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "Warning");
        }

        private void ShowError_Click(object sender, RoutedEventArgs e)
        {
            TestNotifications.ShowError("Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "Error");
        }

        private void CloseAll_Click(object sender, RoutedEventArgs e)
        {
            TestNotifications.CloseAllAsync();
        }
    }
}