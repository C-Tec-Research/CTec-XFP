﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace CTecControls.UI.Notifications
{
    /// <summary>
    /// Interface of the notification manager
    /// </summary>
    public interface INotificationManager
    {
        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <param name="text">The text that should be displayed</param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync(string text, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default);

        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <param name="identifier">The identifier used for the notification</param>
        /// <param name="text">The text that should be displayed</param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync(Guid identifier, string text, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default);

        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <param name="content">The <see cref="NotificationContent"/> that should be displayed</param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync(NotificationContent content, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default);

        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <param name="identifier">The identifier used for the notification</param>
        /// <param name="content">The <see cref="NotificationContent"/> that should be displayed</param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync(Guid identifier, NotificationContent content, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default);

        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <typeparam name="TViewModel">Must implement <see cref="INotificationViewModel"/></typeparam>
        /// <param name="viewModel">A Caliburn Micro view model that should be used. Must implement <see cref="INotificationViewModel"/></param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync<TViewModel>(TViewModel viewModel, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default) where TViewModel : INotificationViewModel;

        /// <summary>
        /// Shows a notification message
        /// </summary>
        /// <typeparam name="TViewModel">Must implement <see cref="INotificationViewModel"/></typeparam>
        /// <param name="identifier">The identifier used for the notification</param>
        /// <param name="viewModel">A Caliburn Micro view model that should be used. Must implement <see cref="INotificationViewModel"/></param>
        /// <param name="areaName">The name of the area in which the notification should appear</param>
        /// <param name="expiryTime">A <see cref="TimeSpan"/> after which the notification disappears</param>
        /// <param name="token">The cancellation token that should be used</param>
        Task ShowAsync<TViewModel>(Guid identifier, TViewModel viewModel, string? areaName = null, TimeSpan? expiryTime = null, CancellationToken token = default) where TViewModel : INotificationViewModel;

        /// <summary>
        /// Closes a notification message, if it is currently visible
        /// </summary>
        /// <param name="identifier">The identifier of the notification</param>
        Task CloseAsync(Guid identifier);

        /// <summary>
        /// Closes all currently visible notification messages
        /// </summary>
        Task CloseAllAsync();
    }
}