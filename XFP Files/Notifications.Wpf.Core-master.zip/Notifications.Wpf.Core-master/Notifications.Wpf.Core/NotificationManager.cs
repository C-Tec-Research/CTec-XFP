﻿using CTecControls.UI.Notifications.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace CTecControls.UI.Notifications
{
    /// <summary>
    /// Implementation of the <see cref="INotificationManager"/> interface. Provides methods to show notification messages
    /// </summary>
    internal class NotificationManager : INotificationManager
    {
        //private static readonly List<NotificationArea> Areas = new List<NotificationArea>();
        private static NotificationArea Area;
        private static NotificationsOverlayWindow? _window;

        private readonly Dispatcher _dispatcher;
        private readonly NotificationPosition _mainNotificationPosition;

        /// <summary>
        /// Creates an instance of the <see cref="NotificationManager"/>
        /// </summary>
        public NotificationManager() : this(NotificationPosition.BottomRight, null)
        {
        }

        /// <summary>
        /// Creates an instance of the <see cref="NotificationManager"/>
        /// </summary>
        /// <param name="mainNotificationPosition">The position where notifications with no custom area should
        /// be displayed</param>
        public NotificationManager(NotificationPosition mainNotificationPosition) : this(mainNotificationPosition, null)
        {
        }

        /// <summary>
        /// Creates an instance of the <see cref="NotificationManager"/>
        /// </summary>
        /// <param name="dispatcher">The <see cref="Dispatcher"/> that should be used</param>
        public NotificationManager(Dispatcher? dispatcher) : this(NotificationPosition.BottomRight, dispatcher)
        {
        }

        /// <summary>
        /// Creates an instance of the <see cref="NotificationManager"/>
        /// </summary>
        /// <param name="mainNotificationPosition">The position where notifications with no custom area should
        /// be displayed</param>
        /// <param name="dispatcher">The <see cref="Dispatcher"/> that should be used</param>
        public NotificationManager(NotificationPosition mainNotificationPosition,
            Dispatcher? dispatcher)
        {
            _mainNotificationPosition = mainNotificationPosition;

            if (dispatcher == null)
            {
                dispatcher = Application.Current?.Dispatcher ?? Dispatcher.CurrentDispatcher;
            }

            _dispatcher = dispatcher;
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync(string, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync(string text, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default)
        {
            await ShowAsync(Guid.NewGuid(), text, areaName, expirationTime, token);
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync(Guid, string, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync(Guid identifier, string text, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default)
        {
            await publicShowAsync(identifier, text, areaName, expirationTime, token);
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync(NotificationContent, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync(NotificationContent content, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default)
        {
            await ShowAsync(Guid.NewGuid(), content, areaName, expirationTime, token);
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync(Guid, NotificationContent, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync(Guid identifier, NotificationContent content, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default)
        {
            await publicShowAsync(identifier, content, areaName, expirationTime, token);
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync{TViewModel}(TViewModel, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync<TViewModel>(TViewModel viewModel, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default) 
            where TViewModel : INotificationViewModel
        {
            await ShowAsync(Guid.NewGuid(), viewModel, areaName, expirationTime, token);
        }

        /// <inheritdoc cref="INotificationManager.ShowAsync{TViewModel}(Guid, TViewModel, string?, TimeSpan?, CancellationToken)"/>
        public async Task ShowAsync<TViewModel>(Guid identifier, TViewModel viewModel, string? areaName = null, TimeSpan? expirationTime = null, CancellationToken token = default) 
            where TViewModel : INotificationViewModel
        {
            viewModel.SetNotificationIdentifier(identifier);

            await publicShowAsync(identifier, viewModel, areaName, expirationTime, token);
        }

        //public static void AddArea(NotificationArea area)
        //{
        //    while (Areas.Count > 0)
        //        Areas.RemoveAt(Areas.Count - 1);

        //    if (Areas.Count == 0)
        //        Areas.Add(area);
        //}

        //public static void RemoveArea(NotificationArea area)
        //{
        //    Areas.Remove(area);
        //}

        public static void SetArea(NotificationArea area) => Area = area;

        private async Task publicShowAsync(Guid identifier, object content, string? areaName, TimeSpan? expirationTime, CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                return;
            }

            if (!_dispatcher.CheckAccess())
            {
                await _dispatcher.BeginInvoke(
                    new Action(async () => await publicShowAsync(identifier, content, areaName, expirationTime, token)));
                return;
            }

            if (expirationTime == null)
            {
                expirationTime = TimeSpan.FromSeconds(5);
            }

            var appWindow = Application.Current.MainWindow;
            _window = new NotificationsOverlayWindow
            {
                Left = appWindow.Left,
                Top = appWindow.Top,
                Width = appWindow.Width,
                Height = appWindow.Height,
                Owner = appWindow,
            };

            _window.SetNotificationAreaPosition(_mainNotificationPosition);
            _window.Show();


            if (token.IsCancellationRequested)
            {
                return;
            }

            try
            {
                if (Area != null)
                    await Area.ShowAsync(identifier, content, (TimeSpan)expirationTime, token);
            }
            catch { }
        }

        /// <inheritdoc cref="INotificationManager.CloseAsync(Guid)"/>
        public async Task CloseAsync(Guid identifier)
        {
            if (Area != null)
                await Area.CloseAsync(identifier);
        }

        /// <inheritdoc cref="INotificationManager.CloseAllAsync"/>
        public async Task CloseAllAsync()
        {
            if (Area != null)
                await Area.CloseAllAsync();
        }
    }
}