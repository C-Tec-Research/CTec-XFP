﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CTecControls.UI.Notifications
{
    public class TestNotifications
    {
        private static readonly NotificationManager _notificationManager = new NotificationManager(Controls.NotificationPosition.BottomRight);


        /// <summary>Show an information notification in the bottom-right corner of the app window</summary>
        public static async void Show(string message, string title)        => await _notificationManager.ShowAsync(new NotificationContent { Title = title, Message = message, Type = NotificationType.Information });
        
        
        /// <summary>Show a success notification in the bottom-right corner of the app window</summary>
        public static async void ShowSuccess(string message, string title) => await _notificationManager.ShowAsync(new NotificationContent { Title = title, Message = message, Type = NotificationType.Success });
        
        
        /// <summary>Show a warning notification in the bottom-right corner of the app window</summary>
        public static async void ShowWarning(string message, string title) => await _notificationManager.ShowAsync(new NotificationContent { Title = title, Message = message, Type = NotificationType.Warning });

        
        /// <summary>Show an error notification in the bottom-right corner of the app window</summary>
        public static async void ShowError(string message, string title)   => await _notificationManager.ShowAsync(new NotificationContent { Title = title, Message = message, Type = NotificationType.Error });

        
        /// <summary>Close notification by its id</summary>
        public static async void CloseAsync(Guid identifier) => await _notificationManager.CloseAsync(identifier);


        /// <summary>Close all notifications</summary>
        public static async void CloseAllAsync() => await _notificationManager.CloseAllAsync();
    }
}
