﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using CTecUtil;
using CTecUtil.UI.Util;
using CTecControls.UI;
using Xfp.ViewModels;
using Xfp.Config;
using Microsoft.Toolkit.Uwp.Notifications;

namespace Xfp.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            EventLog.WriteInfo("Starting app");

            FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement), new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

            InitializeComponent();

            DataContext = _context = new MainWindowViewModel(this);

            //restoreWindowState();
        }


        private bool _allowSaveWindowState = false;

        private MainWindowViewModel _context;


        private void window_Loaded(object sender, RoutedEventArgs e) { }



        #region Window controls & resizing
        private void btnMinimise_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups();*/ WindowState = WindowState.Minimized; }
        private void btnMaximise_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups();*/ WindowState = WindowState.Maximized; XfpApplicationConfig.Settings.MainWindow.IsMaximised = true; /*updateWindowParams(true);*/ }
        private void btnRestore_Click(object sender, RoutedEventArgs e) { /*_context.ClosePopups(); XfpApplicationConfig.Instance.RestoreMainWindowState(this);*/ WindowState = WindowState.Normal; XfpApplicationConfig.Settings.MainWindow.IsMaximised = false; /*updateWindowParams(true);*/ }
        private void window_StateChanged(object sender, EventArgs e) { /*_context.ClosePopups();*/ _context.ChangeWindowState(WindowState); }
        private void btnExit_Click(object sender, RoutedEventArgs e) => exitApp();

        private void window_SizeChanged(object sender, SizeChangedEventArgs e) { updateWindowParams(); }
        private void window_LocationChanged(object sender, EventArgs e) {updateWindowParams(); }

        private void mouseLeftButtonDown_DragMove(object sender, MouseButtonEventArgs e) { try { DragMove(); updateWindowParams(); } catch { } }

        /// <summary>App lost focus</summary>
        private void app_Deactivated(object sender, EventArgs e) { }

        /// <summary>Alt-F4</summary>
        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e) => exitApp(e);

        private void exitApp(System.ComponentModel.CancelEventArgs e = null)
        {
            XfpApplicationConfig.Settings.UpdateMainWindowParams(this, true);
            EventLog.WriteInfo("Exiting app");
            _context?.ExitApp();
        }


        private void updateWindowParams() { if (_allowSaveWindowState) XfpApplicationConfig.Settings.UpdateMainWindowParams(this, _context.LayoutTransform.ScaleX); }

        private void restoreWindowState()
        {
            if (App.AnotherInstanceIsRunning)
                XfpApplicationConfig.Settings.OffsetMainWindowPosition();

            if (XfpApplicationConfig.Settings.MainWindow.Location is null)
                this.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            else
                _context.ChangeWindowState(this.WindowState = WindowUtil.SetWindowDimensions(this, XfpApplicationConfig.Settings.MainWindow));

            this.BringIntoView();
        }


        #region prevent maximised window from being clipped
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            WindowUtil.PreventClipWhenMaximised(this);
        }
        #endregion


        #endregion



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //AppNotification.Show("Test notification", "line 2", "Line 3", "Fourth line", "etc.");
            ShowNotification("Test notification", "line 2", "Line 3", "Fourth line", "etc.");
        }


        public static void ShowNotification(params string[] text)
        {
            var notification = new ToastContentBuilder();

            notification.AddInlineImage(new Uri("pack://application:,,,/Xfp;component/Resources/xfp.ico"));
            notification.AddInlineImage(new Uri("pack://application:,,,/Xfp;component/UI/Images/xfp.ico"));

            for (int i = 0; i < text.Length && i < 3; i++)
                notification.AddText(text[i]);

            notification.Show(toast => { toast.ExpirationTime = DateTime.Now.AddMinutes(15); });
        }


    }
}
