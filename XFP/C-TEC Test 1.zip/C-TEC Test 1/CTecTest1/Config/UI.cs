﻿using System.Windows.Media;

namespace Xfp.Config
{
    public class UI
    {
        public static ScaleTransform LayoutTransform { get; set; }
    }
}
